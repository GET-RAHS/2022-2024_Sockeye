
// libraries

#include <SD.h>
#include <Ethernet.h> // native ethernet really

// Teensy
#define TEENSY_RESET_PIN 28

// flags
#define SD_FLAG       1 << 0
#define BMS_FLAG      1 << 1
#define INA_SBAT_FLAG 1 << 2
#define INA_MOT1_FLAG 1 << 3
#define INA_MOT2_FLAG 1 << 4
#define INA_SOL1_FLAG 1 << 5
#define INA_SOL2_FLAG 1 << 6
#define INA_SOL3_FLAG 1 << 7
#define INA_SOL4_FLAG 1 << 8
#define INA_BATT_FLAG 1 << 9
#define DPS_FLAG      1 << 10
#define GPS_FIX_FLAG  1 << 11
#define GPS_KPH_FLAG  1 << 12
#define GPS_ALT_FLAG  1 << 13
#define GPS_SAT_FLAG  1 << 14
#define GPS_TIM_FLAG  1 << 15

// exc
#define TNSY_RESET    1 << 0
#define ALT_RESET     1 << 1
#define INA_INIT      1 << 2
#define INA_ZERO      1 << 3

// SD card

uint8_t const SDCARD_CS = BUILTIN_SDCARD;  //chip select pin for the MicroSD Card Adapter
char name[] = "YYMMDD00.CSV";
char file[]= "YYMMDD00";

// Networking
// MySQL login info
char local_user[] = "rahs";
char local_password[] = "Rai$beck";

char cloud_user[] = "root";              // MySQL user login username
char cloud_password[] = "iFDkumtqbm2Nb58x";        // MySQL user login password

// Database info
const char schema[] = "GET23";

const char table[] = "get31_data";
const char cumulative_table[] = "cumulative";

// ip addresses
const IPAddress arduino_addr(169,254,62,2);
const IPAddress server_addr(169,254,62,213);

const IPAddress cloud_addr(34,105,4,89);

byte mac_addr[] = { 0xA8, 0x61, 0x0A, 0xAE, 0x84, 0x7B }; // mac address