#pragma once

const char FAILED_MSG[] = "Read failed. Value set: 0.0";

unsigned long iteration = 0;