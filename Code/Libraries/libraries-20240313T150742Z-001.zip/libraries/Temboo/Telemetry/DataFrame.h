/*

Sort of dissapointed with this.
Wasn't competent enough to make it actually good.

*/


#pragma once

#include <Arduino.h>
#include <logger.h>

#include "interfaces/Network.h"
#include "interfaces/SDCard.h"

#include "data/INA.h"
#include "data/DPS.h"
#include "data/GPS.h"
#include "data/BMS.h"
#include "data/MPPT.h"

#include <MySQL_Cursor.h> // https://github.com/ChuckBell/MySQL_Connector_Arduino

struct DataFrame {
    unsigned long start;
    unsigned long end;
    
    char query[6000] = "";
    char labels[3000] = ""; // [todo] :(
    char valueFormat[3000] = "";

    int n = 0;

    File* sd_file = NULL;

    // DataFrame(File* file)
    // {
    //     start = millis();
    //     sd_file = file;
    //     Log(&Serial,0,"DataFrame Time start:",start);
    // }
    DataFrame()
    {
        start = millis();
        Log(&Serial,0,"DataFrame Time start:",start);
    }
    ~DataFrame()
    {
        Log(&Serial,0,"DataFrame","exists no longer!");
    }
};

const char queryBase[] = "INSERT INTO %s.%s (%s) VALUES (%s)";

int stupid_pow(int base, int power) // :c
{
    int x = base;
    for (int i=0;i<power-1;i++)
    {
        x*=base;
    }
    return x;
}

int floatToIntWithPrecision(const float *x, int places)
{
    int factor = stupid_pow(10, places);
    float result = (factor*(*x));
    return (int)result;
}

void InsertV(DataFrame* dataFrame, const char* name, const char* val)
{
    // Below is >.<
    //strcpy(tempF, floatPiece.Type); // put type value into temp variable

    strcat(dataFrame->labels, dataFrame->n != 0 ? "," : "");
    strcat(dataFrame->labels, name); // concatenate type value to string which holds all value labels ex. (label1, label2, label3)
    strcat(dataFrame->valueFormat, dataFrame->n !=0 ? "," : "");
    strcat(dataFrame->valueFormat, val); // concatenate value type to string which holds all value formats ex. (%d, %d, %d)  

    // if (iteration!=0) {
    //     _log_sdcard(sdf, val);
    // }
    // Log(&Serial,0,"Label construction: ",dataFrame->labels);
    // Log(&Serial,0,"Value format construction: ",dataFrame->valueFormat);
    Log(&Serial,0,name,val); // [todo] change logger system to have priority level for data values
    dataFrame->n++;
}

void InsertV(DataFrame* dataFrame, const char* name, const int* val)
{
    // Below is >.<

    char fBuffer[12];
    //strcpy(tempF, floatPiece.Type); // put type value into temp variable
    
    sprintf(fBuffer, "%d", *val);
    strcat(dataFrame->labels, dataFrame->n != 0 ? "," : "");
    strcat(dataFrame->labels, name); // concatenate type value to string which holds all value labels ex. (label1, label2, label3)
    strcat(dataFrame->valueFormat, dataFrame->n !=0 ? "," : "");
    strcat(dataFrame->valueFormat, fBuffer); // concatenate value type to string which holds all value formats ex. (%d, %d, %d)  

    // if (iteration!=0) {
    //     _log_sdcard(sdf, val);
    // }
    // Log(&Serial,0,"Label construction: ",dataFrame->labels);
    // Log(&Serial,0,"Value format construction: ",dataFrame->valueFormat);
    Log(&Serial,0,name,*val); // [todo] change logger system to have priority level for data values
    dataFrame->n++;
}

void InsertV(DataFrame* dataFrame, const char* name, const unsigned int* val)
{
    // Below is >.<

    char fBuffer[12];
    //strcpy(tempF, floatPiece.Type); // put type value into temp variable

    sprintf(fBuffer, "%u", *val);
    strcat(dataFrame->labels, dataFrame->n != 0 ? "," : "");
    strcat(dataFrame->labels, name); // concatenate type value to string which holds all value labels ex. (label1, label2, label3)
    strcat(dataFrame->valueFormat, dataFrame->n !=0 ? "," : "");
    strcat(dataFrame->valueFormat, fBuffer); // concatenate value type to string which holds all value formats ex. (%d, %d, %d)  

    // if (iteration!=0) {
    //     _log_sdcard(sdf, val);
    // }
    // Log(&Serial,0,"Label construction: ",dataFrame->labels);
    // Log(&Serial,0,"Value format construction: ",dataFrame->valueFormat);
    Log(&Serial,0,name,*val); // [todo] change logger system to have priority level for data values
    dataFrame->n++;
}

void InsertV(DataFrame* dataFrame, const char* name, const unsigned long* val)
{
    // Below is >.<

    char fBuffer[12];
    //strcpy(tempF, floatPiece.Type); // put type value into temp variable

    sprintf(fBuffer, "%lu", *val);
    strcat(dataFrame->labels, dataFrame->n != 0 ? "," : "");
    strcat(dataFrame->labels, name); // concatenate type value to string which holds all value labels ex. (label1, label2, label3)
    strcat(dataFrame->valueFormat, dataFrame->n !=0 ? "," : "");
    strcat(dataFrame->valueFormat, fBuffer); // concatenate value type to string which holds all value formats ex. (%d, %d, %d)  

    // if (iteration!=0) {
    //     _log_sdcard(sdf, val);
    // }
    // Log(&Serial,0,"Label construction: ",dataFrame->labels);
    // Log(&Serial,0,"Value format construction: ",dataFrame->valueFormat);
    Log(&Serial,0,name,*val); // [todo] change logger system to have priority level for data values
    dataFrame->n++;
}


// [todo] maybe only temp vars passed in and print by index
// [todo] make this way leaner -- directly add to queue instead of this duplicate variable nonsense -- OR maybe use pointers entirely instead
void InsertV(DataFrame* dataFrame, const char* name, const float* val, int places) // Maybe not efficient // maybe char* rather [todo]
{
    // Log(&Serial,0,"Places from InsertFloat: ",*places);
    // FloatPiece floatPiece = FloatPiece(name, val, places); // new float piece
    // dataFrame->FloatPieces[dataFrame->nFloat] = floatPiece;
    // dataFrame->curPiece++;
    // Log(&Serial,0,"Before float n: ",dataFrame->nFloat);
    //dataFrame->nFloat++;
    // dataFrame->LastFloat = floatPiece;

    int fIntWithPrecision = floatToIntWithPrecision(val, places);

    // Log(&Serial,0,"fIntWithPrecision: ",fIntWithPrecision);
    // Log(&Serial,0,"New float n: ",dataFrame->nFloat);

    // Log(&Serial,0,"Val from InsertFloat: ",*val);

    // Below is >.<

    char fBuffer[12];
    //strcpy(tempF, floatPiece.Type); // put type value into temp variable

    sprintf(fBuffer, "%d", fIntWithPrecision);
    
    strcat(dataFrame->labels, dataFrame->n != 0 ? "," : "");
    strcat(dataFrame->labels, name); // concatenate type value to string which holds all value labels ex. (label1, label2, label3)
    strcat(dataFrame->valueFormat, dataFrame->n !=0 ? "," : "");
    strcat(dataFrame->valueFormat, fBuffer); // concatenate value type to string which holds all value formats ex. (%d, %d, %d)  

    // if (iteration!=0) {
    //     _log_sdcard(sdf, val);
    // }
    Log(&Serial,0,name,*val); // [todo] change logger system to have priority level for data values
    dataFrame->n++;
}

// Define functions for sending

void ConstructQuery(DataFrame* dataFrame, const char* schema, const char* table) // Should only be used for current loop // [todo]: test size of dataframe struct 
{
    // int formatSize = sizeof(dataFrame->valueFormat)/sizeof(dataFrame->valueFormat[0]);
    // int labelSize = sizeof(dataFrame->labels)/sizeof(dataFrame->labels[0]);

    // dataFrame->valueFormat[formatSize-1] = ''; // :C
    // dataFrame->labels[labelSize-1] = ''; // :C

    // Log(&Serial,0,"valueFormat",dataFrame->valueFormat);
    // Log(&Serial,0,"labels",dataFrame->labels);

    // Log(&Serial,0,"Labels: ",dataFrame->labels);
    // Log(&Serial,0,"Value format: ",dataFrame->valueFormat);

    // Never use again
    // for (unsigned int i=0;i<dataFrame->nFloat;i++) // [todo] Change [note] very wonky 
    // {
    //     Serial.print("Iteration in ConstructQuery: "); Serial.print(dataFrame->nFloat); Serial.print(" - ");Serial.println(i);
    //     Serial.print("Value format: "); Serial.println(dataFrame->valueFormat);
    //     Serial.print("Val from ConstructQuery: "); Serial.println(dataFrame->FloatPieces[i].Val);
    //     fVal(dataFrame->valueFormat, &dataFrame->FloatPieces[i].Val, &dataFrame->FloatPieces[i].Places);
    //     //delay(250);
    // }

    strcpy(dataFrame->query, "");
    sprintf(dataFrame->query, queryBase, schema, table, dataFrame->labels, dataFrame->valueFormat); // Assemble the query completely
    
    // Log(&Serial,0,"Query from ConstructQuery: ",dataFrame->query);
}

// void newline_sdcard(DataFrame* dataFrame)
// {
//     if (iteration==0)
//     {
//         sdf->println(dataFrame->labels);
//         Log(&Serial,0,"SD card header:",dataFrame->labels);
//     }
// }

void ExecuteQuery(DataFrame* dataFrame, MySQL_Cursor* cursor) // Executes the query
{
    cursor->execute(dataFrame->query); // Hopefully works
}

// Define debugging stuff

// void Print(DataFrame* dataFrame, HardwareSerial* serial, unsigned int flag) // Print for debugging
// {

//     switch (flag) 
//     {
//         case 0:
//             serial->println(dataFrame->LastFloat.Val); // Print last variable inserted to data frame
//             break;
//         case 1:
//             // finish this
//             break;
//     }

// }

// void Print(DataFrame*, const HardwareSerial*, unsigned int);