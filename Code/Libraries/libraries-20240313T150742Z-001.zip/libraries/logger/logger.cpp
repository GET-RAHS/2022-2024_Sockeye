#include <logger.h>
#include <Arduino.h>

struct {
    unsigned int NOTE = 0;
    unsigned int WARNING = 1;
    unsigned int ERROR = 2;
    unsigned int FATAL = 3;
} DEBUG;

bool Debug = false;
int Priority = 0;

struct {
    char NOTE[10] = "";//"[NOTE] ";
    char WARNING[12] = "[WARNING] ";
    char ERROR[10] = "[ERROR] ";
    char FATAL[10] = "[FATAL] ";
} Priorities;

//char layout[] = "%s %s %s"

char separator[] = " ---> ";

void setDebug(bool debug)
{
    Debug = debug;
}

void setPriority(int priority)
{
    Priority = priority;
}


// make better priority system


// we dont use templates around here :)

// Log system
void Log(usb_serial_class* serial, const int flag, const char* message, const int v)
{
    if (Debug)
    {
        switch (flag) 
        {
            case 0:
                serial->print(Priorities.NOTE);serial->print(message);serial->print(separator);serial->println(v);
            break;
        }
    }
}

// Overload for floats
void Log(usb_serial_class* serial, const int flag, const char* message, const float v)
{
    if (Debug)
    {
        switch (flag) 
        {
            case 0:
                serial->print(Priorities.NOTE);serial->print(message);serial->print(separator);serial->println(v);
            break;
        }
    }
}

void Log(usb_serial_class* serial, const int flag, const char* message, const char* v)
{
    if (Debug)
    {
        switch (flag) 
        {
            case 0:
                serial->print(Priorities.NOTE);serial->print(message);serial->print(separator);serial->println(v);
            break;
        }
    }
}

void Log(usb_serial_class* serial, const int flag, const char* message, const unsigned int v)
{
    if (Debug)
    {
        switch (flag) 
        {
            case 0:
                serial->print(Priorities.NOTE);serial->print(message);serial->print(separator);serial->println(v);
            break;
        }
    }
}

void Log(usb_serial_class* serial, const int flag, const char* message, const double v)
{
    if (Debug)
    {
        switch (flag) 
        {
            case 0:
                serial->print(Priorities.NOTE);serial->print(message);serial->print(separator);serial->println(v);
            break;
        }
    }
}

void Log(usb_serial_class* serial, const int flag, const char* message, const unsigned long v)
{
    if (Debug)
    {
        switch (flag) 
        {
            case 0:
                serial->print(Priorities.NOTE);serial->print(message);serial->print(separator);serial->println(v);
            break;
        }
    }
}