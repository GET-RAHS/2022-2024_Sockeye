#pragma once

#include <Arduino.h>

void setDebug(bool);
void setPriority(int);

// Function overload > templates
void Log(usb_serial_class*, const int, const char*, const int);
void Log(usb_serial_class*, const int, const char*, const float);
void Log(usb_serial_class*, const int, const char*, const char*);
void Log(usb_serial_class*, const int, const char*, const unsigned int);
void Log(usb_serial_class*, const int, const char*, const double);
void Log(usb_serial_class*, const int, const char*, const unsigned long);