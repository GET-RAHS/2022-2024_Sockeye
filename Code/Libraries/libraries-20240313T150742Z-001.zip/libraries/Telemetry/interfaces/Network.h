#pragma once

#include <Arduino.h>
#include <Ethernet.h> // https://github.com/arduino-libraries/Ethernet // native ethernet really. kept it as Ethernet.h to not have to rename all other references
//#include <NativeEthernet.h> // https://github.com/vjmuzik/NativeEthernet
#include <MySQL_Connection.h> // https://github.com/ChuckBell/MySQL_Connector_Arduino
#include <MySQL_Cursor.h> // https://github.com/ChuckBell/MySQL_Connector_Arduino

#include <logger.h>

bool network_connect(byte* mac_addr)
{
    Ethernet.begin(mac_addr);
    Log(&Serial,0,"Connecting to network ...","");

    return Ethernet.linkStatus()==LinkON;
}

bool database_connect(MySQL_Connection* connection, const IPAddress* connection_addr, char* user, char* password)
{
    if (connection->connect(*connection_addr, 3306, user, password)) {
        delay(1000);
        return true;
    } else {
        return false;
    }
}

MySQL_Cursor* mysql_execute(MySQL_Connection* connection, const char* query) // [todo] maybe have the option for speed or multiple database
{
    MySQL_Cursor* cursor = new MySQL_Cursor(connection);
    cursor->execute(query);
    return cursor;
}

void memsafe_mysql_execute(MySQL_Connection* connection, const char* query) // [todo] maybe have the option for speed or multiple database
{
    MySQL_Cursor* cursor = mysql_execute(connection,query);
    delete cursor;   
}