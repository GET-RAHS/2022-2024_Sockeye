#pragma once

#include <Arduino.h>
#include <logger.h>
#include <status.h>

#include <Wire.h>

struct OWI2C {
    uint8_t address;

    OWI2C(const char addr)
    {
        address=addr;
        Wire.begin(addr);
        Wire.
    }
    ~OWI2C()
    {
    }
};

void receive_all(OWI2C* device)
{

}

