#pragma once

#include <Arduino.h>
#include <logger.h>
#include <status.h>

struct BMS {
    HardwareSerial * serial;
    byte request[6] = {0};
    byte data[140] = {0};
    byte datain[140] = {0};
    byte serialflush[64] = {0};

    unsigned int n_cells;

    unsigned int U16Checksum; // [138, 139]
    unsigned int U16Result; // 

    unsigned int read_tries = 0;

    // long A32;
    // unsigned long U32;
    // short Temp;

    unsigned long PhysCap; // [75, 78]
    unsigned long RemCap; // [79, 82]
    unsigned long CyclCap; // [83, 86]

    int BattCharge; // [74]
    int BattV; // x10 [4, 5]
    int BattA; // x10 [72,73]
    int BattW; // [111, 114]

    int HighVNum; // [115]
    int HighV; // [116, 117]
    
    int AvgV; // [121, 122]

    int LowVNum; // [118]
    int LowV; // [119, 120]

    // not sure what these temps are
    // in celcius
    int MOS_Temp; // [91, 92]
    int TBal; // [93, 94] not entirely sure what this is //Balance temp tMos,tBal,T1Neg,T2,T3,T4Pos,charMOS,disMOS,BAL?
    int Temp1Neg; // [95, 96]
    int Temp2; // [99, 100]
    int Temp3; // [101, 102]
    int Temp4Pos; // [97, 98]

    int CharMOS; // [103]
    int DisMOS; // [104]
    int BalState; // [105]

    int* CellV;

    unsigned long Time; // [87, 90]
    unsigned int WheelCircmm; // WheelCircmm AY [106, 107]
    unsigned int MagPairs; // MagPairs AZ [108, 109]
    // unsigned int RelSwitch; // Relswich BA [110] what is this?
    unsigned int NumCells; // [123]


    BMS(HardwareSerial* s, unsigned int n)
    {
        serial=s;
        n_cells=n;
        CellV = new int[n];
    }
    ~BMS()
    {
        
    }
};

void _request_bms_data(BMS* bms, byte* request, size_t size) {
    // for (unsigned int i=0;i<size;i++)
    // {
    //     bms->serial->write(request[i]);
    // }
    bms->serial->write(request,size);
}

bool _raw_read_bms(BMS* bms) {
    bms->read_tries = 0;
    start:
    for (byte j = 87; j < 91; j++) {
        bms->datain[j] = 0;
    }
    int a = bms->serial->readBytes(bms->datain, 140);
    Serial.print("BMS Bytes receieved: ");Serial.println(a);

    bms->U16Result = 0;
    //if(bmsin[0]==0xaa && bmsin[1]==0x55 && bmsin[2]==0xaa &&bmsin[3] ==0xff){      //Check Header
    for (int i = 4; i < 138; i++) {
        bms->U16Result = bms->U16Result + bms->datain[i]; //Result=Ckecksum?
    }

    bms->U16Checksum = (bms->datain[138] << 8) + bms->datain[139]; //Checksum

    bool checksum_matching = bms->U16Result == bms->U16Checksum;
    if (!checksum_matching) {
        bms->read_tries++;
        Log(&Serial,0,"[BMS] checksum not matching. Tries:",bms->read_tries);
        if (bms->read_tries<10)
        {
            goto start;
        } else {
            Log(&Serial,0,"[BMS] maximum tries reached (10).","Continuing . . ");
        }
    }

    // if(jj==0||U16Result!=U16Checksum){jj=jj+1; goto start; }                                        //Test Checsum

    //if (jj==10){                                                                     // Keep reading streaming BMS for delay and then save good last array  jj=900 for 1 minute, approx 15 for 1 sec.

    for (int j = 0; j < 140; j++) {
        bms->data[j] = bms->datain[j];
    }

    return checksum_matching;
}

void _format_bms_data(BMS* bms) {
    bms->Time = ((unsigned long) bms->data[87] << 24) + ((unsigned long) bms->data[88] << 16) + ((unsigned long) bms->data[89] << 8) + bms->data[90];
    /*x10*/bms->BattV = (bms->data[4] << 8) + bms->data[5];
    /*x10*/bms->BattA = (bms->data[72] << 8) + (bms->data[73]);
    bms->BattW = (long(bms->data[111]) << 24) + (long(bms->data[112]) << 16) + (long(bms->data[113]) << 8) + bms->data[114];
    bms->BattCharge = bms->data[74];
    /*x1000000?*/bms->PhysCap = ((unsigned long) bms->data[75] << 24) + ((unsigned long) bms->data[76] << 16) + (bms->data[77] << 8) + (bms->data[78]);
    /*x1000000?*/bms->RemCap = ((unsigned long) bms->data[79] << 24) + ((unsigned long) bms->data[80] << 16) + (bms->data[81] << 8) + bms->data[82];
    /*x1000000?*/bms->CyclCap = ((unsigned long) bms->data[83] << 24) + ((unsigned long) bms->data[84] << 16) + (bms->data[85] << 8) + bms->data[86];
    bms->HighVNum = bms->data[115];
    /*x1000*/bms->HighV = (bms->data[116] << 8) + bms->data[117];
    /*x1000*/bms->AvgV = (bms->data[121] << 8) + bms->data[122];
    bms->LowVNum = bms->data[118];
    /*x1000*/bms->LowV = (bms->data[119] << 8) + bms->data[120];
    bms->MOS_Temp = (bms->data[91] << 8) + bms->data[92];
    
    // vv not entirely sure what these temps are
    bms->TBal = (bms->data[93] << 8) + bms->data[94];
    bms->Temp1Neg = (bms->data[95] << 8) + bms->data[96];
    bms->Temp2 = (bms->data[99] << 8) + bms->data[100];
    bms->Temp3 = (bms->data[101] << 8) + bms->data[102];
    bms->Temp4Pos = (bms->data[97] << 8) + bms->data[98];
    
    bms->CharMOS = bms->data[103];
    bms->DisMOS = bms->data[104];
    bms->BalState = bms->data[105];

    // V1-V32 x1000
    for (unsigned int i = 1; i <= bms->n_cells; i++) {
        bms->CellV[i-1] = (bms->data[2 * i + 4] << 8) + bms->data[2 * i + 5]; // check maximum (likely 32)
    }

    bms->WheelCircmm = (bms->data[106] << 8) + bms->data[107];

    // dont know what these are
    bms->MagPairs = (bms->data[108] << 8) + bms->data[109];
    // bms->RelSwitch = bms->data[110];
    bms->NumCells = bms->data[123];

}

void _init_bms(BMS* bms) {
    bms->serial->begin(9600);
    bms->serial->setTimeout(30);
}

// change to this when uploading for old car
// void _init_bms(BMS* bms) {
//     bms->serial->begin(19200);
//     bms->serial->setTimeout(30);
// }
