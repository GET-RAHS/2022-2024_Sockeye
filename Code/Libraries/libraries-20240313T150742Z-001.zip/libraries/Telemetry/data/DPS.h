#pragma once

#include <Arduino.h>
#include <Adafruit_DPS310.h>
#include <logger.h>

#include <status.h>

struct DPS {
    Adafruit_DPS310* dps;
    Adafruit_DPS310_Temp* dpsT;
    Adafruit_DPS310_Pressure* dpsP;
    float Temp = 0.0;
    float Press = 0.0;
    float LastPress = 0.0;

    float PressHpa = 0.0;
    float PressM = 0.0;
    int AltResetPin;

    char Label[16+1];

    uint8_t I2C_Address = 0x00;

    bool suc = false;

    DPS()
    {
        dps = new Adafruit_DPS310();
        dpsT = new Adafruit_DPS310_Temp(dps);
        dpsP = new Adafruit_DPS310_Pressure(dps);
    }
    DPS(const uint8_t address)
    {
        dps = new Adafruit_DPS310();
        dpsT = new Adafruit_DPS310_Temp(dps);
        dpsP = new Adafruit_DPS310_Pressure(dps);
        I2C_Address = address;
    }
    DPS(const char* label, int altimeter_reset_pin)
    {
        Log(&Serial,0,"DPS new","!");
        dps = new Adafruit_DPS310();
        dpsT = new Adafruit_DPS310_Temp(dps);
        dpsP = new Adafruit_DPS310_Pressure(dps);
        AltResetPin = altimeter_reset_pin;
        strcpy(Label, label);
    }
    DPS(const char* label, const uint8_t address)
    {
        dps = new Adafruit_DPS310();
        dpsT = new Adafruit_DPS310_Temp(dps);
        dpsP = new Adafruit_DPS310_Pressure(dps);
        I2C_Address = address;
        strcpy(Label, label);
    }
    ~DPS() // not using
    {
        delete dps;
        delete dpsT;
        delete dpsP;
    }
};

void _read_dps_T(DPS* dps)
{
    if (dps->suc)
    {
        sensors_event_t temperature_event;
        if (dps->dps->temperatureAvailable())
        {
            dps->dpsT->getEvent(&temperature_event);          //(AS)
            //    sd_file.print(pressure_event.pressure); sd_file.print(',');               //(AS)
            float Temp = temperature_event.pressure;
            dps->Temp = Temp; //(AS)
        }
    } else {
        dps->Temp=0.0;
        Log(&Serial,0,dps->Label,FAILED_MSG);
    }
    
}
void _read_dps_P(DPS* dps)
{
    if (dps->suc)
    {
        if (digitalRead(dps->AltResetPin))
        {
            dps->LastPress=dps->Press;
        }
        sensors_event_t pressure_event;
        if (dps->dps->pressureAvailable())
        {
            dps->dpsP->getEvent(&pressure_event);          //(AS)
            //    sd_file.print(pressure_event.pressure); sd_file.print(',');               //(AS)
            float Pressure = pressure_event.pressure;
            dps->Press = Pressure; //(AS)
            float PressHpa = Pressure - dps->LastPress;
            dps->PressHpa = PressHpa;
            dps->PressM = PressHpa*9.0;
        }
    } else {
        dps->Press=0.0;
        dps->PressHpa=0.0;
        dps->PressM=0.0;
        Log(&Serial,0,dps->Label,FAILED_MSG);
    }
}

bool _init_dps(DPS* dps)
{
    bool success;
    if (dps->I2C_Address) {
        success = dps->dps->begin_I2C(dps->I2C_Address);
    } else {
        success = dps->dps->begin_I2C();
    }
    dps->dps->configurePressure(DPS310_64HZ, DPS310_128SAMPLES);
    dps->dps->configureTemperature(DPS310_64HZ, DPS310_128SAMPLES);
    dps->suc = success;
    Log(&Serial,0,dps->Label,success?"Success":"Fail");

    return success;
}