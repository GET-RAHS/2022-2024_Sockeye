#pragma once

#include <Arduino.h>
#include <INA226.h> // https://github.com/RobTillaart/INA226
#include <Wire.h> // I2C interface
#include <logger.h>

#include <status.h>

struct INA {
    INA226* sensor;
    float A = 0.0;
    float AZ = 0.0;
    float AF = 1.0; // to not make the value zero by default
    float V = 0.0;
    float VZ = 0.0;
    float VF = 1.0;
    bool suc = false;

    int MAX_A;
    int OHM;
    int BVCT;
    int SVCT;
    int AVG;
    char Label[16+1];

    INA()
    {
        Log(&Serial,0,"INA226","Missing arguments");
    }
    INA(const uint8_t address,int max_a, float resistor_ohm, int bvct, int svct, int avg, float vf, float af, const char* label)
    {
        sensor = new INA226(address);
        MAX_A=max_a;
        OHM=resistor_ohm;
        BVCT=bvct;
        SVCT=svct;
        AVG=avg;
        VF=vf;
        AF=af;

        strcpy(Label, label);
    }
    INA(TwoWire* wire, const uint8_t address,int max_a, float resistor_ohm, int bvct, int svct, int avg, float vf, float af, const char* label)
    {
        sensor = new INA226(address,wire);
        MAX_A=max_a;
        OHM=resistor_ohm;
        BVCT=bvct;
        SVCT=svct;
        AVG=avg;
        VF=vf;
        AF=af;

        strcpy(Label, label);
    }
    
    ~INA() // not using
    {
        delete sensor;
    }
};

float _raw_read_ina_A(INA226* ina)
{
    return ina->getShuntVoltage_mV();
}

float _raw_read_ina_V(INA226* ina)
{
    return ina->getBusVoltage();
}

void _read_ina_A(INA* ina, bool Z)
{
    if (ina->suc)
    {
        float raw = _raw_read_ina_A(ina->sensor);
        ina->A = (raw-(Z?ina->AZ:0))*(ina->AF);
        Serial.print(ina->Label);
        Log(&Serial,0," raw read (A):",raw);
    } else {
        ina->A=0.0;
        Log(&Serial,0,ina->Label,FAILED_MSG);
    }
}
void _read_ina_V(INA* ina, bool Z/*why?*/)
{
    if (ina->suc)
    {
        float raw = _raw_read_ina_V(ina->sensor);
        ina->V = (raw-(Z?ina->VZ:0))*(ina->VF);
        Serial.print(ina->Label);
        Log(&Serial,0," raw read (V):",raw);
    } else {
        ina->V=0.0;
        Log(&Serial,0,ina->Label,FAILED_MSG);
    }
}

bool _init_ina(INA* ina)
{
    bool status = ina->sensor->begin();
    ina->suc = status;

    ina->sensor->setMaxCurrentShunt(ina->MAX_A, ina->OHM);
    ina->sensor->setBusVoltageConversionTime(ina->BVCT);
    ina->sensor->setShuntVoltageConversionTime(ina->SVCT);
    ina->sensor->setAverage(ina->AVG);

    float AZero = _raw_read_ina_A(ina->sensor);
    ina->AZ = AZero;

    float VZero = _raw_read_ina_V(ina->sensor);
    ina->VZ = VZero;

    Log(&Serial,0,ina->Label,status?"Success":"Fail");
    Log(&Serial,0,"^\tZero (A): ",AZero);
    Log(&Serial,0,"^\tZero (V): ",VZero);

    return status;
}