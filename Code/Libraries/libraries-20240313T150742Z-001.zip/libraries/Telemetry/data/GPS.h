#pragma once

#include <Arduino.h>
#include <logger.h>
#include <status.h>

#include <NMEAGPS.h> // https://github.com/SlashDevin/NeoGPS      GPS library
#include <ublox/ubxGPS.h>
#include <GPSfix_cfg.h>
#include <GPSfix.h> // do I need this?

unsigned long Unix2000=946684800;
unsigned long PST = 0;//-28800+60*60;

const unsigned char ubxRate1Hz[] PROGMEM =
{ 0x06,0x08,0x06,0x00,0xE8,0x03,0x01,0x00,0x01,0x00 };
const unsigned char ubxRate5Hz[] PROGMEM =
{ 0x06,0x08,0x06,0x00,200,0x00,0x01,0x00,0x01,0x00 };
const unsigned char ubxRate10Hz[] PROGMEM =
{ 0x06,0x08,0x06,0x00,100,0x00,0x01,0x00,0x01,0x00 };
const char baud38400 [] PROGMEM = "PUBX,41,1,3,3,38400,0";

struct GPS {
    NMEAGPS* gps;
    gps_fix fix;
    HardwareSerial* port;

    int last_fix = 0;
    unsigned long unix;
    unsigned long centi;
    char unix_str[13+1];
    float lat;
    float lon;
    float kph;
    bool success = false;

    GPS(HardwareSerial* gps_port) // runs when you make a GPS instance
    {
        gps = new NMEAGPS(); // new instance of NMEAGPS
        port = gps_port;
    }

    ~GPS()
    {
        delete gps;
    }
};

void fmt3d(char*str, uint8_t v) {  //function to translate an number 0 to 99
  if (v > 999) return;               // to a string of 2 characters
  uint8_t n1 = v / 100; // 5
  uint8_t n0 = v - 100 * n1; // 0
  *str++ = '0' + n1;
  *str = '0' + n0;
}

// a problem I will work on later
// void three_dec(char*str, uint8_t v)
// {
//     uint8_t n1 = v/100;
//     uint8_t n2 = 
// }

void _centi_to_milli_str(char* buffer, int val)
{
    if (val==0)
    {
        strcpy(buffer, "000");
    } else {
        sprintf(buffer,"%d",val);
    }
}

NMEAGPS _gps;
gps_fix fix;

#define gpsPort Serial3

void sendUBX( const unsigned char *progmemBytes, size_t len )
{
  gpsPort.write( 0xB5 ); // SYNC1
  gpsPort.write( 0x62 ); // SYNC2

  uint8_t a = 0, b = 0;
  while (len-- > 0) {
    uint8_t c = pgm_read_byte( progmemBytes++ );
    a += c;
    b += a;
    gpsPort.write( c );
  }
  gpsPort.write( a ); // CHECKSUM A
  gpsPort.write( b ); // CHECKSUM B
}

gps_fix::valid_t _gps_getfix(GPS* gps)
{
    retry:
    if (_gps.available( gpsPort )) {    // Test delay necessary to get a fix jj is number of tries
        fix = _gps.read();
    } else goto retry;

    gps->fix = fix;

    //Serial.println(1.5);
    // Serial.print (jj); Serial.print(','); Serial.print(fix.dateTime);  Serial.print(',');

    return fix.valid;
}

void _read_gps_year(GPS* gps)
{

}

// assuming time is valid
void _format_unix(GPS* gps)
{
    char milli[4+1];
    _centi_to_milli_str(milli, gps->centi*10);
    sprintf(gps->unix_str,"%lu%s",gps->unix,milli);
}

// assuming fix is valid
void _read_gps_centi(GPS* gps)
{
    gps->centi=gps->fix.dateTime_cs;
    if (gps->fix.valid.time)
    {
        Log(&Serial,0,"Unix centi","is valid");
    } else {
        Log(&Serial,0,"Unix centi","is invalid");
    }
}

// assuming fix is valid
void _read_gps_unix(GPS* gps)
{
    unsigned long unix = gps->fix.dateTime;
    Log(&Serial,0,"Unix read",unix);
    gps->unix = unix+Unix2000+PST;
    if (gps->fix.valid.time)
    {
        Log(&Serial,0,"Unix sec","is valid");
    } else {
        Log(&Serial,0,"Unix sec","is invalid");
    }
    _read_gps_centi(gps);
    _format_unix(gps);
}

void _read_gps_loc(GPS* gps)
{
    if (gps->fix.valid.location)
    {
        gps->lat = gps->fix.latitude();
        gps->lon = gps->fix.longitude();
    }  else {
        Log(&Serial,0,"GPS latitude:",FAILED_MSG);
        Log(&Serial,0,"GPS longtitude:",FAILED_MSG);
    }
}

// dangerous
void _read_gps_kph(GPS* gps)
{
    gps->kph = gps->fix.speed_kph();
    if (gps->fix.valid.speed)
    {
        Log(&Serial,0,"GPS kph","is valid");
    } else {
        Log(&Serial,0,"GPS kph","is valid");
    }
}

void _init_gps(GPS* gps)
{
    gps->port->begin(9600); //Serial 3, Pins 14 & 15

    gps->gps->send_P(gps->port, (const __FlashStringHelper *)baud38400);
    gps->port->flush(); // wait for the command to go out
    delay(100); // wait for the GPS device to change speeds
    gps->port->end(); // empty the input buffer, too
    gps->port->begin(38400); // use the new baud rate

    sendUBX(ubxRate10Hz, sizeof(ubxRate10Hz));
}