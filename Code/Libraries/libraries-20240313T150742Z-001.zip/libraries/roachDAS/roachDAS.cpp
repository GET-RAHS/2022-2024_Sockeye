// FAT Data Acquisition System
// By Timothy
//
//

/*
[reminders]

    *dont use duplicate var for first 2 args of sprintf
    *optimize after, not before

*/

#include <roachDAS.h>

const char queryBase[] = "INSERT INTO %s.%s %s VALUES %s";

int stupid_pow(int base, int power) // :c
{
    int x = base;
    for (int i=0;i<power-1;i++)
    {
        x*=base;
    }
    return x;
}

int floatToIntWithPrecision(const float *x, int places) // Converts floats to integers with precision
{
    int factor = stupid_pow(10, places);
    float result = (factor*(*x));
    Log(&Serial,0,"Multiply by: ",(int)factor);
    Log(&Serial,0,"Val at conversion: ",*x);
    Log(&Serial,0,"Result at conversion: ",result);
    return (int)result;
} 

// Terrible...
// void fVal(char* buffer, char* format, float* val, int* places) // Inserts float into value buffer [todo] optimize or find a better way entirely
// {
//     char temp[sizeof(buffer)/sizeof(buffer[0])];
//     strcpy(temp, buffer);

//     Serial.print("Places: "); Serial.println(*places);
//     int iVal = floatToIntWithPrecision(val, places); // Maybe?
//     Serial.print("iVal: "); Serial.println(iVal);
//     Serial.print("Temp: "); Serial.println(temp);
//     sprintf(buffer, temp, iVal);
//     Serial.print("Buffer: "); Serial.println(buffer);
// }

// where I left off

void InsertV(DataFrame* dataFrame, const char* name, const char* val)
{
    // Below is >.<

    char fBuffer[12];
    char tempF[3];
    //strcpy(tempF, floatPiece.Type); // put type value into temp variable
    strcpy(tempF, "%s");

    sprintf(fBuffer, tempF, val);
    strcat(dataFrame->labels, name); // concatenate type value to string which holds all value labels ex. (label1, label2, label3)
    strcat(dataFrame->labels, ",");
    strcat(dataFrame->valueFormat, strcat(fBuffer, ",")); // concatenate value type to string which holds all value formats ex. (%d, %d, %d) // [todo]: maybe insert the value instead of having to do it later

    Log(&Serial,0,"Label construction: ",dataFrame->labels);
    Log(&Serial,0,"Value format construction: ",dataFrame->valueFormat);
}

void InsertV(DataFrame* dataFrame, const char* name, const int* val)
{
    // Below is >.<

    char fBuffer[12];
    char tempF[3];
    //strcpy(tempF, floatPiece.Type); // put type value into temp variable
    strcpy(tempF, "%d");

    sprintf(fBuffer, tempF, *val);
    strcat(dataFrame->labels, name); // concatenate type value to string which holds all value labels ex. (label1, label2, label3)
    strcat(dataFrame->labels, ",");
    strcat(dataFrame->valueFormat, strcat(fBuffer, ",")); // concatenate value type to string which holds all value formats ex. (%d, %d, %d) // [todo]: maybe insert the value instead of having to do it later

    Log(&Serial,0,"Label construction: ",dataFrame->labels);
    Log(&Serial,0,"Value format construction: ",dataFrame->valueFormat);
}

// [todo] maybe only temp vars passed in and print by index
// [todo] make this way leaner -- directly add to queue instead of this duplicate variable nonsense -- OR maybe use pointers entirely instead
void InsertV(DataFrame* dataFrame, const char* name, const float* val, int places) // Maybe not efficient // maybe char* rather [todo]
{
    // Log(&Serial,0,"Places from InsertFloat: ",*places);
    // FloatPiece floatPiece = FloatPiece(name, val, places); // new float piece
    // dataFrame->FloatPieces[dataFrame->nFloat] = floatPiece;
    // dataFrame->curPiece++;
    // Log(&Serial,0,"Before float n: ",dataFrame->nFloat);
    dataFrame->nFloat++;
    // dataFrame->LastFloat = floatPiece;

    int fIntWithPrecision = floatToIntWithPrecision(val, places);

    Log(&Serial,0,"fIntWithPrecision: ",fIntWithPrecision);
    Log(&Serial,0,"New float n: ",dataFrame->nFloat);

    Log(&Serial,0,"Val from InsertFloat: ",*val);

    // Below is >.<

    char fBuffer[12];
    char tempF[3];
    //strcpy(tempF, floatPiece.Type); // put type value into temp variable
    strcpy(tempF, "%d");

    sprintf(fBuffer, tempF, fIntWithPrecision);
    strcat(dataFrame->labels, name); // concatenate type value to string which holds all value labels ex. (label1, label2, label3)
    strcat(dataFrame->labels, ",");
    strcat(dataFrame->valueFormat, strcat(fBuffer, ",")); // concatenate value type to string which holds all value formats ex. (%d, %d, %d) // [todo]: maybe insert the value instead of having to do it later

    Log(&Serial,0,"Label construction: ",dataFrame->labels);
    Log(&Serial,0,"Value format construction: ",dataFrame->valueFormat);
}

// Define functions for sending

void ConstructQuery(DataFrame* dataFrame, const char* schema, const char* table) // Should only be used for current loop // [todo]: test size of dataframe struct 
{
    // int formatSize = sizeof(dataFrame->valueFormat)/sizeof(dataFrame->valueFormat[0]);
    // int labelSize = sizeof(dataFrame->labels)/sizeof(dataFrame->labels[0]);

    // dataFrame->valueFormat[formatSize-1] = ''; // :C
    // dataFrame->labels[labelSize-1] = ''; // :C

    strcat(dataFrame->valueFormat, "0)"); // >.<
    strcat(dataFrame->labels, "end)"); // >.<

    Log(&Serial,0,"Labels: ",dataFrame->labels);
    Log(&Serial,0,"Value format: ",dataFrame->valueFormat);

    // Never use again
    // for (unsigned int i=0;i<dataFrame->nFloat;i++) // [todo] Change [note] very wonky 
    // {
    //     Serial.print("Iteration in ConstructQuery: "); Serial.print(dataFrame->nFloat); Serial.print(" - ");Serial.println(i);
    //     Serial.print("Value format: "); Serial.println(dataFrame->valueFormat);
    //     Serial.print("Val from ConstructQuery: "); Serial.println(dataFrame->FloatPieces[i].Val);
    //     fVal(dataFrame->valueFormat, &dataFrame->FloatPieces[i].Val, &dataFrame->FloatPieces[i].Places);
    //     //delay(250);
    // }

    sprintf(dataFrame->query, queryBase, schema, table, dataFrame->labels, dataFrame->valueFormat); // Assemble the query completely
    
    Log(&Serial,0,"Query from ConstructQuery: ",dataFrame->query);
}

void ExecuteQuery(DataFrame* dataFrame, MySQL_Cursor* cursor) // Executes the query
{
    cursor->execute(dataFrame->query); // Hopefully works
}

// Define debugging stuff

// void Print(DataFrame* dataFrame, HardwareSerial* serial, unsigned int flag) // Print for debugging
// {

//     switch (flag) 
//     {
//         case 0:
//             serial->println(dataFrame->LastFloat.Val); // Print last variable inserted to data frame
//             break;
//         case 1:
//             // finish this
//             break;
//     }

// }