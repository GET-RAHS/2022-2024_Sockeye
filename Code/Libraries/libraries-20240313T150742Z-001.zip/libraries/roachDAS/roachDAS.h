#pragma once
#include <Arduino.h>
#include <logger.h>

#include <MySQL_Cursor.h> // https://github.com/ChuckBell/MySQL_Connector_Arduino

// Float Piece definition [todo]: think about removing this entirely (absolute memory thief)
// struct FloatPiece {
//     char Type[3] = "%d";
//     char Name[16];
//     int Places;
//     float Val;
//     int fIntWithPrecision;
//     FloatPiece() 
//     {
//         strcpy(Type, "default_type");
//         strcpy(Name, "default_name");
//         Val = 0.0;
//     }
//     FloatPiece(const char* name, const float *val, const int* places) 
//     {
//         Log(&Serial,0,"Places from FloatPiece: ",*places);
//         //strcpy(Type, "%d"); // [todo]: consider using float
//         strcpy(Name, name);
//         Val = *val;
//         Places = *places;
//     }
// };

// DataFrame definition
// Absolute memory destroyer
struct DataFrame {
    unsigned long start;
    unsigned long end;
    
    // query buffers
    char query[2000];
    char labels[500] = "("; // [todo] :(
    char valueFormat[500] = "(";

    unsigned int curPiece;
    
    unsigned int nFloat = 0;
    // FloatPiece LastFloat;
    // FloatPiece FloatPieces[80];

    DataFrame() 
    {
        start = millis();
        Serial.print("Time start: "); Serial.println(start);
    }
    ~DataFrame()
    {
        Serial.println("Exist no more!");
    }
};

void InsertV(DataFrame*, const char*, const float*, int);
void InsertV(DataFrame*, const char*, const char*);
void InsertV(DataFrame*, const char*, const int*);
void ConstructQuery(DataFrame*, const char*, const char*);
void ExecuteQuery(DataFrame*, const MySQL_Cursor*);

// void Print(DataFrame*, const HardwareSerial*, unsigned int);