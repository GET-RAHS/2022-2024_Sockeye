#FreqMeasure Library#

FreqMeasure measures the elapsed time during each cycle of an input frequency.

http://www.pjrc.com/teensy/td_libs_FreqMeasure.html

![FreqMeasure and Test Equipment](http://www.pjrc.com/teensy/td_libs_FreqMeasure_1.jpg)
