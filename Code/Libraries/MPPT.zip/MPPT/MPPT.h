#pragma once

#include <Arduino.h>
#include <logger.h>
#include <status.h>

// #include <SPI.h>
// #include <mcp2515.h>
#include <FlexCAN_T4.h>

// MCP2515::ERROR _mppt_read_message(MCP2515* mcp2515, can_frame* frame)
// {
//     MCP2515::ERROR status = mcp2515->readMessage(frame);

//     return status;
// }

// MCP2515::ERROR _mppt_broadcast_message(MCP2515* mcp2515, can_frame* frame)
// {
//     MCP2515::ERROR status = mcp2515->sendMessage(frame);

//     return status;
// }

// bool _mppt_read_message(FlexCAN_T4<_bus, _rxSize, _txSize>* can, CAN_message_t* msg)
// {
//     if (can->read(*msg))
//     {
//         return true;
//     } else {
//         return false;
//     }
// }

// bool _mppt_broadcast_message(FlexCAN_T4<_bus, _rxSize, _txSize>* can,msg)
// {
//     if (can->write(*msg))
//     {
//         return true;
//     } else {
//         return false;
//     }
// }