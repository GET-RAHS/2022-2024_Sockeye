#pragma once

#include <Arduino.h>
#include <SD.h>
#include <SPI.h>
#include <logger.h>

void fmt2d(char*str, uint8_t v) {  //function to translate an number 0 to 99
  if (v > 99) return;               // to a string of 2 characters
  uint8_t n1 = v / 10;
  uint8_t n0 = v - 10 * n1;
  *str++ = '0' + n1;
  *str = '0' + n0;
}
bool make_file_date_name(char* name, uint8_t y, uint8_t m, uint8_t d) {    //functiom to build up file name
  fmt2d(name, y);                                                      //by date and file number
  fmt2d(name + 2, m);                                                  //and Open SD card file
  fmt2d(name + 4, d);
  for (uint8_t n = 0; n < 100; n++) {
    fmt2d(name + 6, n);
    if (!SD.exists(name))
    {
        return true;
    } else {
        continue;
    }
  }
  return false;
}

bool _init_sdcard(const uint8_t chipSelect)
{
    // pinMode(48, OUTPUT); //Red---SD card Fault
    // pinMode(49, OUTPUT); //Green--SD card OK
    bool success = SD.begin(chipSelect);

    Log(&Serial,0,"SD card begin",success?"success":"fail");
    return success;
}

void _open_sdcard(File* sd_file, char* name, uint8_t y, uint8_t m, uint8_t d)
{
    bool name_success = make_file_date_name(name, y, m, d);

    Log(&Serial,0,"SD card file open",name_success?"success":"fail");
    if (name_success)
    {
        //digitalWrite(49, HIGH); digitalWrite(48, LOW); //48 red , 49 green
        // Serial.println(2.75);
        *sd_file = SD.open(name, FILE_WRITE);
        Log(&Serial,0,"SD card file name",name);
        digitalWrite(3, HIGH); // Green

    } else {
        digitalWrite(2, HIGH); // Red
        Log(&Serial,0,"SD card file name","failed. why?");
        //Serial.println("open failed");
        //digitalWrite(49, LOW); digitalWrite(48, HIGH); // 48 red , 49 green
    }
}

void _close_sdcard(File* sd_file)
{
    sd_file->flush();
    //sd_file->close();
}


